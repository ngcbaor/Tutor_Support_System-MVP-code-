import React from 'react';

const MyBorrowsPage = () => {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-4">My Borrows</h2>
      <p className="text-gray-600">This page is under construction.</p>
    </div>
  );
};

export default MyBorrowsPage;
