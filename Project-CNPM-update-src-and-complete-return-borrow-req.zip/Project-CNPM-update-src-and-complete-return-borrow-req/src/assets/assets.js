import background from './background.svg'
import logo from './logo.svg'
import search_icon from './search_icon.svg'
import polygon_icon from './polygon_icon.svg'
import user_icon from './user_icon.svg'  // Icon cho Sign In button (ở ngoài folder icons)

// Import icons from icons folder
import home_icon from './icons/home_icon.svg'
import browse_icon from './icons/browse_icon.svg'
import rules_icon from './icons/rules_icon.svg'
import users_icon from './icons/users_icon.svg'  // Icon cho menu Users của admin
import mybor from './icons/mybor.svg'
import myreq from './icons/myreq.svg'
import approved from './icons/approved.svg'
import return_icon from './icons/return_icon.svg'
import borrow_admin from './icons/borrow_admin.svg'
import books from './icons/Vector.svg'
import bell from './icons/bell.svg'

import book_img_1 from './book_img_1.png'
import book_img_2 from './book_img_2.png'

export const assets = {
    background,
    logo,
    home_icon,
    browse_icon,
    rules_icon,
    search_icon,
    polygon_icon,
    user_icon,        // Dùng cho Sign In button
    users_icon,       // Dùng cho menu Users (admin)
    books,
    bell,             // Dùng cho notification
    // Icon aliases với tên mới
    myborrows_icon: mybor,
    myrequest_icon: myreq,
    approved_icon: approved,
    return_icon,
    borrow_admin_icon: borrow_admin,
    
    book_img_1,
    book_img_2,
}


